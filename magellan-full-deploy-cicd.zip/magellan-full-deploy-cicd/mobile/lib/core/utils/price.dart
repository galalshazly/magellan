
String formatSAR(int halalah) {
  return "${(halalah/100).toStringAsFixed(2)} SAR";
}
